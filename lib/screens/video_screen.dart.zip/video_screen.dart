import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class VideoScreen extends StatefulWidget {
  const VideoScreen({super.key});

  @override
  State<VideoScreen> createState() => _VideoScreenState();
}

class _VideoScreenState extends State<VideoScreen> {
  final youtubesLink = [
    'PQSagzssvUQ',
    'jwRqDjRLXcQ',
    'z-Y7nmvzEZc',
    'XOnL41-nTw0',
    'KUt97zRPGuw'
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Column(
        children: [
          const SizedBox(
            height: 10,
          ),
          Expanded(
              child: ListView.builder(
            itemCount: 5,
            itemBuilder: (context, int index) {
              return _youtubeVideo(youtubesLink[index]);
            },
          ))
        ],
      ),
    );
  }

  Widget _youtubeVideo(videoLink) {
    return Column(
      children: [
        YoutubePlayer(
          controller: YoutubePlayerController(
            initialVideoId: videoLink,
            flags: const YoutubePlayerFlags(
              autoPlay: false,
              mute: false,
            ),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
      ],
    );
  }
}
